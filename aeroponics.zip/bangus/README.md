# PHP-MySQL-Login-System
User login and registration system built using PHP and MySQL .

**Live Project URL -** [PHP-MySQL-Login-System](https://live-demo97.000webhostapp.com/)

![screenshot](./img/screenshot-1.png)
![screenshot](./img/screenshot-2.png)
![screenshot](./img/screenshot-3.png)
![screenshot](./img/screenshot-4.png)
![screenshot](./img/screenshot-5.png)
![screenshot](./img/screenshot-6.png)
